import React from "react";

import { NavLink } from "react-router-dom";

const Navigation = () => {
  return (
    <div>
      <NavLink to="/">
        <i class="material-icons">flight</i> Flight
      </NavLink>
      <NavLink to="/about">
        <i class="material-icons">hotel</i>Flight + Hotel
      </NavLink>
      <NavLink to="/contact">
        <i class="material-icons">hotel</i>Hotels
      </NavLink>

      <NavLink to="/contact">
        <i class="material-icons">directions_car</i>Car Hire
      </NavLink>
    </div>
  );
};

export default Navigation;
